package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    GridLayout gridLayout;
    TextView scoreTextView;
    ArrayList<Integer> cards = new ArrayList<>();
    ArrayList<ImageView> imageViews = new ArrayList<>();
    boolean[] isCardFlipped = new boolean[16];

    int firstCardIndex = -1;
    int secondCardIndex = -1;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridLayout = findViewById(R.id.gridLayout);
        scoreTextView = findViewById(R.id.scoreTextView);

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, StartActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });


        loadCards();
        createImageViews();
    }

    void loadCards() {
        for (int i = 0; i < 8; i++) {
            cards.add(i);
            cards.add(i);
        }
        Collections.shuffle(cards);
    }

    void createImageViews() {
        for (int i = 0; i < 16; i++) {
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(R.drawable.card_back);
            imageView.setTag(i);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();

            int cardSize = getResources().getDimensionPixelSize(R.dimen.card_size);
            int margin = getResources().getDimensionPixelSize(R.dimen.card_margin);

            params.width = cardSize;
            params.height = cardSize;
            params.setMargins(margin, margin, margin, margin);

            imageView.setLayoutParams(params);


            imageView.setOnClickListener(this::onCardClicked);

            imageViews.add(imageView);
            gridLayout.addView(imageView);
        }
    }

    void onCardClicked(View view) {
        int index = (int) view.getTag();

        if (isCardFlipped[index] || secondCardIndex != -1) {
            return;
        }

        imageViews.get(index).setImageResource(getImageResource(cards.get(index)));
        isCardFlipped[index] = true;

        if (firstCardIndex == -1) {
            firstCardIndex = index;
        } else {
            secondCardIndex = index;

            if (cards.get(firstCardIndex).equals(cards.get(secondCardIndex))) {
                score++;
                scoreTextView.setText("Wynik: " + score);
                firstCardIndex = -1;
                secondCardIndex = -1;
            } else {
                int first = firstCardIndex;
                int second = secondCardIndex;

                new android.os.Handler().postDelayed(() -> {
                    imageViews.get(first).setImageResource(R.drawable.card_back);
                    imageViews.get(second).setImageResource(R.drawable.card_back);
                    isCardFlipped[first] = false;
                    isCardFlipped[second] = false;
                    firstCardIndex = -1;
                    secondCardIndex = -1;
                }, 500);
            }
        }
    }

    int getImageResource(int cardValue) {
        switch (cardValue) {
            case 0:
                return R.drawable.image1;
            case 1:
                return R.drawable.image2;
            case 2:
                return R.drawable.image3;
            case 3:
                return R.drawable.image4;
            case 4:
                return R.drawable.image5;
            case 5:
                return R.drawable.image6;
            case 6:
                return R.drawable.image7;
            case 7:
                return R.drawable.image8;
            default:
                return R.drawable.card_back;
        }
    }
}
